# Storage ESP — Fabric 1.21.11

Client-side Fabric mod with a custom dark/cyan ClickGUI.

## Modules
- **StorageESP** — outlines chests, trapped chests, hoppers and all vanilla shulker colors.
- **SpawnerFinder** — outlines monster spawners.
- Per-category RGBA colors, opacity and line-width controls are exposed in the GUI/config.
- Configuration is saved to `config/storageesp.properties`.
- ClickGUI opens with **Right Shift**.

## Build
Requires Java 21 and a network connection so Gradle can download Minecraft/Fabric dependencies.

```bash
./gradlew build
```

The built mod will be in `build/libs/`.

Target: Minecraft **1.21.11**, Fabric Loader **0.18.1+**, Fabric API **0.141.6+1.21.11**.

The project uses Yarn 1.21.11 mappings because Fabric still supports them for this obfuscated Minecraft release; Fabric's 1.21.11 documentation notes that 1.21.11 is the last obfuscated release and that Loom 1.13+ is appropriate for the version.
