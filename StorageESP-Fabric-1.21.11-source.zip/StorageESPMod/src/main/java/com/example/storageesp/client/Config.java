package com.example.storageesp.client;

import java.io.*;
import java.nio.file.*;
import java.util.*;

public final class Config {
    public boolean storageEsp = true;
    public boolean spawnerFinder = true;
    public boolean fill = false;
    public boolean throughWalls = true;
    public int chestColor = 0xFFFFB020;
    public int hopperColor = 0xFFB8C0CC;
    public int shulkerColor = 0xFFB66CFF;
    public int spawnerColor = 0xFF32D8FF;
    public float alpha = 0.85f;
    public float lineWidth = 2.0f;

    private static final Path FILE = net.fabricmc.loader.api.FabricLoader.getInstance().getConfigDir().resolve("storageesp.properties");
    public void load() {
        if (!Files.exists(FILE)) return;
        Properties p = new Properties();
        try (Reader r = Files.newBufferedReader(FILE)) { p.load(r); storageEsp=bool(p,"storage",storageEsp); spawnerFinder=bool(p,"spawner",spawnerFinder); fill=bool(p,"fill",fill); throughWalls=bool(p,"walls",throughWalls); chestColor=hex(p,"chest",chestColor); hopperColor=hex(p,"hopper",hopperColor); shulkerColor=hex(p,"shulker",shulkerColor); spawnerColor=hex(p,"spawnerColor",spawnerColor); alpha=Float.parseFloat(p.getProperty("alpha",Float.toString(alpha))); lineWidth=Float.parseFloat(p.getProperty("lineWidth",Float.toString(lineWidth))); } catch (Exception ignored) {}
    }
    public void save() {
        Properties p=new Properties(); p.setProperty("storage",Boolean.toString(storageEsp)); p.setProperty("spawner",Boolean.toString(spawnerFinder)); p.setProperty("fill",Boolean.toString(fill)); p.setProperty("walls",Boolean.toString(throughWalls)); p.setProperty("chest",String.format("#%08X",chestColor)); p.setProperty("hopper",String.format("#%08X",hopperColor)); p.setProperty("shulker",String.format("#%08X",shulkerColor)); p.setProperty("spawnerColor",String.format("#%08X",spawnerColor)); p.setProperty("alpha",Float.toString(alpha)); p.setProperty("lineWidth",Float.toString(lineWidth));
        try { Files.createDirectories(FILE.getParent()); try(Writer w=Files.newBufferedWriter(FILE)){p.store(w,"Storage ESP configuration");} } catch(Exception ignored) {}
    }
    private static boolean bool(Properties p,String k,boolean d){return Boolean.parseBoolean(p.getProperty(k,Boolean.toString(d)));}
    private static int hex(Properties p,String k,int d){try{return (int)Long.parseLong(p.getProperty(k,String.format("%08X",d)).replace("#",""),16);}catch(Exception e){return d;}}
}
