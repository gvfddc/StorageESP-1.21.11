package com.example.storageesp.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import org.lwjgl.glfw.GLFW;
import java.util.ArrayList;
import java.util.List;

public final class StorageEspClient implements ClientModInitializer {
    public static final Config CONFIG = new Config();
    private static KeyBinding guiKey;
    private static final List<BlockPos> cachedTargets = new ArrayList<>();
    private static int scanTimer = 0;

    @Override public void onInitializeClient() {
        CONFIG.load();
        guiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.storageesp.clickgui", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "key.categories.storageesp"));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while(guiKey.wasPressed()) client.setScreen(new ClickGuiScreen());
            if (client.world != null && client.player != null && ++scanTimer >= 10) { scanTimer = 0; scan(client); }
        });
        WorldRenderEvents.AFTER_ENTITIES.register(StorageEspClient::render);
    }

    private static boolean target(Block b) {
        return b==Blocks.CHEST || b==Blocks.TRAPPED_CHEST || b==Blocks.HOPPER || b==Blocks.SHULKER_BOX || b==Blocks.WHITE_SHULKER_BOX || b==Blocks.ORANGE_SHULKER_BOX || b==Blocks.MAGENTA_SHULKER_BOX || b==Blocks.LIGHT_BLUE_SHULKER_BOX || b==Blocks.YELLOW_SHULKER_BOX || b==Blocks.LIME_SHULKER_BOX || b==Blocks.PINK_SHULKER_BOX || b==Blocks.GRAY_SHULKER_BOX || b==Blocks.LIGHT_GRAY_SHULKER_BOX || b==Blocks.CYAN_SHULKER_BOX || b==Blocks.PURPLE_SHULKER_BOX || b==Blocks.BLUE_SHULKER_BOX || b==Blocks.BROWN_SHULKER_BOX || b==Blocks.GREEN_SHULKER_BOX || b==Blocks.RED_SHULKER_BOX || b==Blocks.BLACK_SHULKER_BOX || b==Blocks.SPAWNER;
    }
    private static int color(Block b){ if(b==Blocks.CHEST||b==Blocks.TRAPPED_CHEST)return CONFIG.chestColor; if(b==Blocks.HOPPER)return CONFIG.hopperColor; if(b==Blocks.SPAWNER)return CONFIG.spawnerColor; return CONFIG.shulkerColor; }

    private static void scan(MinecraftClient mc) {
        cachedTargets.clear();
        BlockPos center = mc.player.getBlockPos();
        int radius = CONFIG.throughWalls ? 40 : 28;
        for (BlockPos pos : BlockPos.iterate(center.add(-radius,-radius,-radius), center.add(radius,radius,radius))) {
            Block b = mc.world.getBlockState(pos).getBlock();
            if (!target(b)) continue;
            if (b == Blocks.SPAWNER ? CONFIG.spawnerFinder : CONFIG.storageEsp) cachedTargets.add(pos.toImmutable());
        }
    }

    private static void render(net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext ctx) {
        MinecraftClient mc=MinecraftClient.getInstance();
        if(mc.world==null || ctx.matrixStack()==null || ctx.consumers()==null || cachedTargets.isEmpty()) return;
        MatrixStack matrices=ctx.matrixStack();
        VertexConsumer vc=ctx.consumers().getBuffer(RenderLayer.getLines());
        matrices.push();
        matrices.translate(-ctx.camera().getPos().x,-ctx.camera().getPos().y,-ctx.camera().getPos().z);
        for(BlockPos pos: cachedTargets){
            Block b=mc.world.getBlockState(pos).getBlock();
            if (b == Blocks.SPAWNER && !CONFIG.spawnerFinder) continue;
            if (b != Blocks.SPAWNER && !CONFIG.storageEsp) continue;
            int c=color(b);
            float a=CONFIG.alpha;
            float r=((c>>16)&255)/255f, g=((c>>8)&255)/255f, bl=(c&255)/255f;
            WorldRenderer.drawBox(matrices,vc,new Box(pos).expand(0.002),r,g,bl,a);
        }
        matrices.pop();
    }

    public static final class ClickGuiScreen extends Screen {
        private int page=0;
        protected ClickGuiScreen(){super(Text.literal("Storage ESP • ClickGUI"));}
        @Override protected void init(){ }
        @Override public void render(net.minecraft.client.gui.DrawContext d,int mx,int my,float delta){
            int w=width,h=height; d.fill(0,0,w,h,0xD80A0C10);
            int left=Math.max(24,w/2-360), top=Math.max(24,h/2-210); int panelW=720,panelH=420;
            d.fill(left,top,left+panelW,top+panelH,0xF014171D); d.fill(left,top,left+panelW,top+3,0xFF32D8FF);
            d.drawText(textRenderer,"STORAGE ESP",left+22,top+18,0xFFFFFFFF,false); d.drawText(textRenderer,"CLIENT",left+22,top+34,0xFF7D8795,false);
            int side=150; d.fill(left+14,top+64,left+side,top+panelH-14,0xFF0E1116);
            String[] cats={"VISUALS","ESP","SETTINGS"}; for(int i=0;i<3;i++){int y=top+82+i*48; boolean sel=i==page; d.fill(left+22,y-7,left+side-8,y+27,sel?0xFF162D38:0x00000000); d.drawText(textRenderer,cats[i],left+34,y+3,sel?0xFF32D8FF:0xFF9AA4B2,false);}
            int x=left+side+32,y=top+72;
            if(page==0){ title(d,"Modules",x,y); toggle(d,"StorageESP",CONFIG.storageEsp,x,y+38); toggle(d,"SpawnerFinder",CONFIG.spawnerFinder,x,y+82); toggle(d,"Fill boxes",CONFIG.fill,x,y+126); toggle(d,"Through walls",CONFIG.throughWalls,x,y+170); }
            else if(page==1){ title(d,"Outline colors",x,y); colorRow(d,"Chest / Trapped Chest",CONFIG.chestColor,x,y+40); colorRow(d,"Hopper",CONFIG.hopperColor,x,y+82); colorRow(d,"Shulker",CONFIG.shulkerColor,x,y+124); colorRow(d,"Spawner",CONFIG.spawnerColor,x,y+166); }
            else { title(d,"Render",x,y); slider(d,"Opacity",CONFIG.alpha,x,y+48,0,1); slider(d,"Line width",CONFIG.lineWidth,x,y+100,1,5); d.drawText(textRenderer,"Right Shift  •  Open ClickGUI",x,y+160,0xFF8E99A8,false); }
            d.drawText(textRenderer,"1.21.11  •  Fabric",left+22,top+panelH-30,0xFF697484,false);
            super.render(d,mx,my,delta);
        }
        private void title(net.minecraft.client.gui.DrawContext d,String s,int x,int y){d.drawText(textRenderer,s,x,y,0xFFFFFFFF,false);}
        private void toggle(net.minecraft.client.gui.DrawContext d,String s,boolean on,int x,int y){d.drawText(textRenderer,s,x,y+8,0xFFD8DEE7,false); d.fill(x+360,y,x+402,y+22,on?0xFF32D8FF:0xFF2A3038); d.fill(x+(on?382:362),y+3,x+(on?399:379),y+19,0xFFFFFFFF);}
        private void colorRow(net.minecraft.client.gui.DrawContext d,String s,int c,int x,int y){d.drawText(textRenderer,s,x,y+8,0xFFD8DEE7,false); d.fill(x+360,y,x+402,y+22,c); d.fill(x+361,y+1,x+401,y+21,(c&0x00FFFFFF)|0x40000000);}
        private void slider(net.minecraft.client.gui.DrawContext d,String s,float v,int x,int y,float min,float max){d.drawText(textRenderer,s,x,y+4,0xFFD8DEE7,false); d.fill(x+180,y+9,x+410,y+13,0xFF29303A); int p=(int)(x+180+(v-min)/(max-min)*230); d.fill(x+180,y+9,p,y+13,0xFF32D8FF); d.fill(p-3,y+4,p+3,y+18,0xFFFFFFFF); d.drawText(textRenderer,String.format("%.2f",v),x+425,y+4,0xFF8E99A8,false);}
        @Override public boolean mouseClicked(double mx,double my,int button){
            int left=Math.max(24,width/2-360),top=Math.max(24,height/2-210); int side=150; int x=left+side+32;
            if(mx>=left+22&&mx<left+150){for(int i=0;i<3;i++)if(my>=top+75+i*48&&my<=top+115+i*48){page=i;return true;}}
            if(page==0&&mx>=x&&mx<x+450){ if(my>=top+105&&my<top+150){CONFIG.storageEsp=!CONFIG.storageEsp;CONFIG.save();return true;} if(my>=top+149&&my<top+194){CONFIG.spawnerFinder=!CONFIG.spawnerFinder;CONFIG.save();return true;} if(my>=top+193&&my<top+238){CONFIG.fill=!CONFIG.fill;CONFIG.save();return true;} if(my>=top+237&&my<top+282){CONFIG.throughWalls=!CONFIG.throughWalls;CONFIG.save();return true;} }
            if(page==1&&mx>=x+330&&mx<x+430){int idx=(int)((my-(top+112))/42);if(idx>=0&&idx<4){int[] cs={0xFFFFB020,0xFFB8C0CC,0xFFB66CFF,0xFF32D8FF};int[] old={CONFIG.chestColor,CONFIG.hopperColor,CONFIG.shulkerColor,CONFIG.spawnerColor};int c=old[idx];int nr=((c<<8)|(c>>>24))|0xFF000000;if(idx==0)CONFIG.chestColor=nr;if(idx==1)CONFIG.hopperColor=nr;if(idx==2)CONFIG.shulkerColor=nr;if(idx==3)CONFIG.spawnerColor=nr;CONFIG.save();return true;}}
            return super.mouseClicked(mx,my,button);
        }
        @Override public boolean shouldPause(){return false;}
    }
}
